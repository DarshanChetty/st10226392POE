﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Recipe_App
{
    /// <summary>
    /// Interaction logic for ucSelectRecipe.xaml
    /// </summary>
    public partial class ucSelectRecipe : UserControl
    {
        private List<Recipe> recipes;

        public ucSelectRecipe(List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;

            
        }

        private void Select_Click(object sender, RoutedEventArgs e)
        {
            string name = txtRecipeName.Text;

            Recipe recipe = recipes.Find(x => x.Name == name);

            if (recipe != null)
            {
                lblRecipeName.Text = "Recipe: " + recipe.Name;
                ShowIngredients(recipe);
                ShowSteps(recipe);
            }
            else
            {
                MessageBox.Show("No Recipe Found", "Select Recipe", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
        }

        public void ShowIngredients(Recipe recipe)
        {
            IngredientsListBox.Items.Clear();
            int totalCalories = 0;

            foreach (Ingredient ingredient in recipe.Ingredients)
            {
                totalCalories += ingredient.Calories;
                string ingredientInfo = $"{ingredient.Name} -   Quantity: {ingredient.Quantity} {ingredient.Unit}, Calories: {ingredient.Calories}, Food Group: {ingredient.FoodGroup}";
                IngredientsListBox.Items.Add(ingredientInfo);
            }

            if (totalCalories > 300)
            {
                lblWarning.Visibility = Visibility.Visible;
            }
        }

        public void ShowSteps(Recipe recipe)
        {
            StepsListBox.Items.Clear();
            int i = 1;
            foreach (string step in recipe.Steps)
            {
                StepsListBox.Items.Add("Step " + i + ": " + step);
                i++;
            }
        }
    }
}
