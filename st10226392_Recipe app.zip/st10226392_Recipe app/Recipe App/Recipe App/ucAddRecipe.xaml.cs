﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Recipe_App
{
    /// <summary>
    /// Interaction logic for ucAddRecipe.xaml
    /// </summary>
    public partial class ucAddRecipe : UserControl
    {
        public ucAddRecipe()
        {
            InitializeComponent();
            ingredients = new List<Ingredient>();
            steps = new List<string>();
            totalCalories = 0;
        }

        public Recipe CreatedRecipe { get; private set; }
        private List<Ingredient> ingredients;
        private List<string> steps;
        private int totalCalories;

        public event EventHandler<RecipeCreatedEventArgs> RecipeCreated;

        protected virtual void OnRecipeCreated(Recipe createdRecipe)
        {
            RecipeCreated?.Invoke(this, new RecipeCreatedEventArgs(createdRecipe));
        }


        private void btnAddIngredient_Click(object sender, RoutedEventArgs e)
        {
            // ingredients

            string inName = txtIngredientName.Text;
            double quantity = double.Parse(txtIngredientQuantity.Text);
            string unit = cmbIngredientUnit.Text;
            int calories = int.Parse(txtIngredientCalories.Text);
            string foodGroup = cmbFoodGroup.Text;

            if (String.IsNullOrEmpty(inName) || String.IsNullOrEmpty(foodGroup) || String.IsNullOrEmpty(unit) || String.IsNullOrEmpty(foodGroup) || quantity == 0)
            {
                MessageBox.Show("Ivalid Inputs", "Add Ingredient", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                totalCalories += calories;
                if ((totalCalories) > 300)
                {
                    MessageBox.Show("Total Calories exceed more than 300", "Calories", MessageBoxButton.OKCancel, MessageBoxImage.Warning);
                }

                Ingredient ing = new Ingredient(inName, quantity, unit, calories, foodGroup);
                ingredients.Add(ing);

                txtIngredientCalories.Text = "0";
                txtIngredientName.Text = string.Empty;
                txtIngredientQuantity.Text = "0";

                lblIng.Content = "Ingredient       Total Ingredients Added: " + ingredients.Count.ToString() + "  Total Calories: " + totalCalories.ToString();
            }
        }

        private void btnAddStep_Click(object sender, RoutedEventArgs e)
        {
            // steps
            string step = txtStep.Text;

            if (String.IsNullOrEmpty(step))
            {
                MessageBox.Show("Invalid Step Input", "Add Steps", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                steps.Add(step);

                txtStep.Text = string.Empty;

                lblSteps.Content = "Steps    Total " + steps.Count.ToString() + " steps Added";
            }
        }

        private void btnCreateRecipe_Click(object sender, RoutedEventArgs e)
        {
            // recipe

            string name = txtRecipeName.Text;

            if (String.IsNullOrEmpty(name))
            {
                MessageBox.Show("Invalid Recipe Name", "Add Recipe", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (ingredients.Count == 0)
            {
                MessageBox.Show("Add some ingredients", "Add Ingredients", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (steps.Count == 0)
            {
                MessageBox.Show("Add some steps", "Add Steps", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            CreatedRecipe = new Recipe(name);
            CreatedRecipe.Calories = totalCalories;
            foreach (Ingredient ingredient in ingredients)
            {
                CreatedRecipe.AddIngredient(ingredient);
            }
            foreach (String step in steps)
            {
                CreatedRecipe.AddStep(step);
            }

            MessageBox.Show("New Recipe Added Successfully", "Recipe", MessageBoxButton.OK, MessageBoxImage.Information);
            // Raise the RecipeCreated event to notify the parent control
            OnRecipeCreated(CreatedRecipe);
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            // clear
            txtIngredientCalories.Text = "0";
            txtIngredientName.Text = string.Empty;
            txtIngredientQuantity.Text = "0";
            txtStep.Text = string.Empty;

            cmbFoodGroup.Text = string.Empty;
            cmbFoodGroup.SelectedIndex = 0;
        }
    }

    public class RecipeCreatedEventArgs : EventArgs
    {
        public Recipe CreatedRecipe { get; }

        public RecipeCreatedEventArgs(Recipe createdRecipe)
        {
            CreatedRecipe = createdRecipe;
        }
    }
}
