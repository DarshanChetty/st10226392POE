﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Recipe_App
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes = new List<Recipe>();
         
        public MainWindow()
        {
            InitializeComponent();
        }

        private void NewRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            ucAddRecipe addRecipeControl = new ucAddRecipe();

            // Wire up an event handler to listen for the RecipeCreated event
            addRecipeControl.RecipeCreated += AddRecipeControl_RecipeCreated;

            // Set the addRecipeControl as the content of the MainContentControl
            MainContentControl.Content = addRecipeControl;
        }

        private void AddRecipeControl_RecipeCreated(object sender, RecipeCreatedEventArgs e)
        {
            // Retrieve the created recipe from the event arguments
            Recipe newRecipe = e.CreatedRecipe;

            if (newRecipe != null)
            {
                // Add the new recipe to the list or perform any other necessary actions
                recipes.Add(newRecipe);

                // Switch the content to the ucViewRecipe control to view the newly created recipe
                ucViewRecipe viewRecipeControl = new ucViewRecipe(newRecipe);
                MainContentControl.Content = viewRecipeControl;
            }
        }

        private void ListRecipesButton_Click(object sender, RoutedEventArgs e)
        {
            // Handle displaying the recipe list
            ucListRecipe listRecipeControl = new ucListRecipe(recipes);
            MainContentControl.Content = listRecipeControl;
        }

        private void SelectRecipe_Click(object sender, RoutedEventArgs e)
        {
            ucSelectRecipe ucSelectRecipe = new ucSelectRecipe(recipes);
            MainContentControl.Content = ucSelectRecipe;
        }

        private void Close_click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Are You Sure you want to exit!", "Exit", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                Close();
            }
        }

    }
}
