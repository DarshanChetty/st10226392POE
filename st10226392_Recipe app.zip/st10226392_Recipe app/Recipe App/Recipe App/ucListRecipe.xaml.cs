﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Recipe_App
{
    /// <summary>
    /// Interaction logic for ucListRecipe.xaml
    /// </summary>
    public partial class ucListRecipe : UserControl
    {
        //private List<Recipe> recipes;
        public ucListRecipe(List<Recipe> recipes)
        {
            InitializeComponent();
            this.allRecipes = recipes;
            lstRecipes.ItemsSource = recipes;
            txtMaxCalories.Text = "0";
        }

        private List<Recipe> allRecipes; // Assuming you have a list of all recipes

        private void FilterButton_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = txtRecipeName.Text;
            string foodGroup = cmbFoodGroup.Text;
            int maxCalories;
            List<Recipe> filteredRecipes = allRecipes;

            if (!int.TryParse(txtMaxCalories.Text, out maxCalories))
            {
                // Handle invalid input for max calories (e.g., non-numeric value)
                return;
            }

            if (!String.IsNullOrEmpty(recipeName))
            {
               filteredRecipes = filteredRecipes.Where(x => x.Name == recipeName).ToList();
            }

            if (!String.IsNullOrEmpty(foodGroup) && foodGroup != "Any")
            {
                filteredRecipes = filteredRecipes.FindAll(x => x.Ingredients.Any(ing => ing.FoodGroup == foodGroup)).ToList();
            }

            if(maxCalories != 0)
            {
                filteredRecipes = filteredRecipes.FindAll(x => x.Calories <=  maxCalories).ToList();
            }

            // Bind the filtered recipes to the ListBox
            lstRecipes.ItemsSource = filteredRecipes;
        }

    }
}
